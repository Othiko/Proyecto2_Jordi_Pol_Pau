package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

public class interficie extends JFrame {
	private JPanel[] mainpanels = new JPanel[5];
	private fightPanel fightpanel;
	private JButton choosecharacter, chooseweapon, ranking, fight, clear;
	private JTextArea console;
	private JScrollPane scrollconsole;
	
	
	public interficie() {
		mainpanels[0] = new JPanel();
		mainpanels[0].setLayout(new BoxLayout(mainpanels[0], BoxLayout.Y_AXIS));
		for (int i=1;i<mainpanels.length;i++) {
			mainpanels[i] = new JPanel();
			mainpanels[i].setLayout(new FlowLayout(FlowLayout.CENTER));
		}
		
		choosecharacter = new JButton("Choose character");
		chooseweapon = new JButton("Choose weapon");
		ranking = new JButton("Ranking");
		fight = new JButton("Fight");
		clear = new JButton("Clear console");
		
		fightpanel = new fightPanel();
		
		console = new JTextArea(7,95);
		scrollconsole = new JScrollPane(console);
		scrollconsole.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
		scrollconsole.setHorizontalScrollBarPolicy ( ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS );
		
		clear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				console.setText("");
				fight.setText("Next Turn");
			}
		});
		
		
		mainpanels[1].add(choosecharacter);
		mainpanels[1].add(chooseweapon);
		mainpanels[1].add(ranking);
		
		mainpanels[2].add(fightpanel);
		
		mainpanels[3].add(fight);
		mainpanels[3].add(clear);
		
		mainpanels[4].add(scrollconsole);
		
		for (int i=1;i<mainpanels.length;i++) {
			mainpanels[0].add(mainpanels[i]);
		}
		
		this.add(mainpanels[0]);
		this.setSize(1000,750);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	class fightPanel extends JPanel {
		private JPanel ally, allyspecifics, allystats, enemy, enemyspecifics, enemystats, healthallypanel, healthenemypanel, characterallypanel, characterenemypanel, allyweaponpanel, enemyweaponpanel, allystatslabelpanel, enemystatslabelpanel;
		private JProgressBar healthally, powerally, agilityally, speedally, defenseally, healthenemy, powerenemy, agilityenemy, speedenemy, defenseenemy;
		private JLabel stat1ally, stat2ally, stat3ally, stat4ally, stat1enemy, stat2enemy, stat3enemy, stat4enemy, characterally, weaponally, characterenemy, weaponenemy;
		
		fightPanel() {
			ally = new JPanel();
			ally.setLayout(new BoxLayout(ally, BoxLayout.Y_AXIS));
			enemy = new JPanel();
			enemy.setLayout(new BoxLayout(enemy, BoxLayout.Y_AXIS));
			
			healthallypanel = new JPanel();
			healthenemypanel = new JPanel();
			characterallypanel = new JPanel();
			characterenemypanel = new JPanel();
			allyspecifics = new JPanel();
			allyspecifics.setLayout(new BorderLayout(5,5));
			enemyspecifics = new JPanel();
			enemyspecifics.setLayout(new BorderLayout(5,5));
			
			allyweaponpanel = new JPanel();
			enemyweaponpanel = new JPanel();
			allystatslabelpanel = new JPanel();
			allystatslabelpanel.setLayout(new BoxLayout(allystatslabelpanel, BoxLayout.Y_AXIS));
			enemystatslabelpanel = new JPanel();
			enemystatslabelpanel.setLayout(new BoxLayout(enemystatslabelpanel, BoxLayout.Y_AXIS));
			allystats = new JPanel();
			allystats.setLayout(new BoxLayout(allystats, BoxLayout.Y_AXIS));
			allystats.setBorder(new EmptyBorder(5,0,0,5));
			enemystats = new JPanel();
			enemystats.setLayout(new BoxLayout(enemystats, BoxLayout.Y_AXIS));
			enemystats.setBorder(new EmptyBorder(5,0,0,5));
			
			healthally = new JProgressBar(0,60); //Cambiar max por vida segun personaje escogido
			healthally.setStringPainted(true);
			healthally.setPreferredSize(new Dimension(330,35));
			healthally.setValue(60);
			healthally.setForeground(Color.green);
			powerally = new JProgressBar(0,11);
			powerally.setPreferredSize(new Dimension(150,25));
			powerally.setValue(7);
			powerally.setForeground(Color.red);
			agilityally = new JProgressBar(0,7);
			agilityally.setPreferredSize(new Dimension(150,25));
			agilityally.setValue(3);
			agilityally.setForeground(Color.pink);
			speedally = new JProgressBar(0,12);
			speedally.setPreferredSize(new Dimension(150,25));
			speedally.setValue(9);
			speedally.setForeground(Color.yellow);
			defenseally = new JProgressBar(0,4);
			defenseally.setPreferredSize(new Dimension(150,25));
			defenseally.setValue(2);
			defenseally.setForeground(Color.blue);
			
			allystats.add(powerally);
			allystats.add(agilityally);
			allystats.add(speedally);
			allystats.add(defenseally);
			
			healthenemy = new JProgressBar(0,60); //Cambiar max por vida segun personaje escogido
			healthenemy.setStringPainted(true);
			healthenemy.setPreferredSize(new Dimension(330,35));
			healthenemy.setValue(60);
			healthenemy.setForeground(Color.green);
			powerenemy = new JProgressBar(0,11);
			powerenemy.setPreferredSize(new Dimension(150,25));
			powerenemy.setValue(7);
			powerenemy.setForeground(Color.red);
			agilityenemy = new JProgressBar(0,7);
			agilityenemy.setPreferredSize(new Dimension(150,25));
			agilityenemy.setValue(3);
			agilityenemy.setForeground(Color.pink);
			speedenemy = new JProgressBar(0,12);
			speedenemy.setPreferredSize(new Dimension(150,25));
			speedenemy.setValue(9);
			speedenemy.setForeground(Color.yellow);
			defenseenemy = new JProgressBar(0,4);
			defenseenemy.setPreferredSize(new Dimension(150,25));
			defenseenemy.setValue(2);
			defenseenemy.setForeground(Color.blue);
			
			enemystats.add(powerenemy);
			enemystats.add(agilityenemy);
			enemystats.add(speedenemy);
			enemystats.add(defenseenemy);
			
			stat1ally = new JLabel("Power");
			stat2ally = new JLabel("Agility");
			stat3ally = new JLabel("Speed");
			stat4ally = new JLabel("Defense");
			allystatslabelpanel.add(stat1ally);
			allystatslabelpanel.add(stat2ally);
			allystatslabelpanel.add(stat3ally);
			allystatslabelpanel.add(stat4ally);
			
			stat1enemy = new JLabel("Power");
			stat2enemy = new JLabel("Agility");
			stat3enemy = new JLabel("Speed");
			stat4enemy = new JLabel("Defense");
			enemystatslabelpanel.add(stat1enemy);
			enemystatslabelpanel.add(stat2enemy);
			enemystatslabelpanel.add(stat3enemy);
			enemystatslabelpanel.add(stat4enemy);
			
			characterally = new JLabel(new ImageIcon("image.png"));
			characterally.setPreferredSize(new Dimension(330,330));
			weaponally = new JLabel(new ImageIcon(new ImageIcon("weapons/katana.png").getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));
			weaponally.setPreferredSize(new Dimension(55,55));
			characterenemy = new JLabel(new ImageIcon("image.png"));
			characterenemy.setPreferredSize(new Dimension(330,330));
			weaponenemy = new JLabel(new ImageIcon(new ImageIcon("weapons/katana.png").getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));
			weaponenemy.setPreferredSize(new Dimension(55,55));
			
			healthallypanel.add(healthally);
			healthenemypanel.add(healthenemy);
			characterallypanel.add(characterally);
			characterenemypanel.add(characterenemy);
			
			allyweaponpanel.add(weaponally);
			enemyweaponpanel.add(weaponenemy);
			
			allyspecifics.add(allyweaponpanel, BorderLayout.WEST);
			allyspecifics.add(allystatslabelpanel, BorderLayout.CENTER);
			allyspecifics.add(allystats, BorderLayout.EAST);
			
			enemyspecifics.add(enemyweaponpanel, BorderLayout.WEST);
			enemyspecifics.add(enemystatslabelpanel, BorderLayout.CENTER);
			enemyspecifics.add(enemystats, BorderLayout.EAST);
			
			ally.add(healthallypanel);
			ally.add(characterallypanel);
			ally.add(allyspecifics);
			
			enemy.add(healthenemypanel);
			enemy.add(characterenemypanel);
			enemy.add(enemyspecifics);
		
			this.setLayout(new BorderLayout(100,10));
			this.add(ally, BorderLayout.WEST);
			this.add(enemy, BorderLayout.EAST);
			
		}
	}
	
	public static void main(String[] args) {
		new interficie();
	}

}
