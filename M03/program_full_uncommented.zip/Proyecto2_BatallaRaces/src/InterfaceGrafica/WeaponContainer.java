package InterfaceGrafica;

import java.util.ArrayList;

public class WeaponContainer {
    private ArrayList<Weapons> weapons;
    public WeaponContainer() {
        this.weapons = new ArrayList<Weapons>();
    }

    public void addNew(Weapons a) {
        this.weapons.add(a);
    }

    public ArrayList<Weapons> getWeapons() {return weapons;}


}
