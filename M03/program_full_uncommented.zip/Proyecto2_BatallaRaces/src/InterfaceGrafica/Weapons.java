package InterfaceGrafica;

import javax.swing.*;
import java.awt.*;

public class Weapons {
    private String name, image;
    private int id, speed, strenght, points;

    public Weapons(int id, String name, int speed, int strenght, String image, int points) {
        this.id = id;
        this.name = name;
        this.speed = speed;
        this.strenght = strenght;
        this.image = image;
        this.points = points;

    }

    public String getImage_Path() {return image;}
    public int getWeaponSpeed() {return speed;}
    public int getWeaponPower() {return strenght;}
    public int getWeaponPoints() {return points;}
}
