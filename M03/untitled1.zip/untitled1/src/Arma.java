import javax.swing.*;
import java.awt.*;

public class Arma {
    private String nom;
    private int id, vel, forca, punts;
    private ImageIcon image;
    private boolean huma, elf, nan;
    public Arma(int id, String nom, int vel, int forca, ImageIcon image, int punts, boolean huma, boolean elf, boolean nan) {
        this.id = id;
        this.nom = nom;
        this.vel = vel;
        this.forca = forca;
        this.image = image;
        this.punts = punts;
        this.huma = huma;
        this.elf = elf;
        this.nan = nan;
    }

    public ImageIcon getImage() {
        return image;
    }
}
