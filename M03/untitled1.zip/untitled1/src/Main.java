import javax.swing.*;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        new Ventana();
    }
}

class Ventana extends JFrame {
    JPanel panel;
    public Ventana() {
        String urlDatos, usuario, pass, query, update;

        urlDatos = "jdbc:mysql://localhost/projecte?serverTimezone=UTC";
        usuario = "root";
        pass = "1234";

        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement statement = conn.createStatement();
            ResultSet rs;

            panel = new JPanel();

            query = "select * from armes where id_arma = 1";
            rs = statement.executeQuery(query);
            
            rs.next();

            Arma daga = new Arma(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), new ImageIcon(rs.getString(5)), rs.getInt(6), rs.getBoolean(7), rs.getBoolean(8), rs.getBoolean(9));

            panel.add(new JLabel(daga.getImage()));


            this.add(panel);
            this.pack();
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
            this.setVisible(true);

        } catch (ClassNotFoundException e) {System.out.println("El driver no se ha cargado correctamente.");}
        catch (SQLException e) {System.out.println("Error de SQL."); e.printStackTrace();}
    }
}