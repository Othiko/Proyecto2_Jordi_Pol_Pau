import java.net.URL;

public abstract class Personatges {
    private int id, punts_raca, vida, forca, defensa, agilitat, velocitat;
    private String nom, raca;
    private URL image_path;
    public Personatges(int id, String nom, URL image_path, String raca, int punts_raca, int vida, int forca, int defensa, int agilitat, int velocitat) {
        this.id = id;
        this.nom = nom;
        this.raca = raca;
        this.image_path = image_path;
        this.punts_raca = punts_raca;
        this.vida = vida;
        this.forca = forca;
        this.defensa = defensa;
        this.agilitat = agilitat;
        this.velocitat = velocitat;
    }


    /* SETTERS */
    public void setId(int id) {this.id = id;}
    public void setNom(String nom) {this.nom = nom;}
    public void setImage_path(URL image_path) {this.image_path = image_path;}
    public void setAgilitat(int agilitat) {this.agilitat = agilitat;}
    public void setDefensa(int defensa) {this.defensa = defensa;}
    public void setForca(int forca) {this.forca = forca;}
    public void setVelocitat(int velocitat) {this.velocitat = velocitat;}
    public void setVida(int vida) {this.vida = vida;}


    /* GETTERS */
    public int getId() {return id;}
    public String getNom() {return nom;}
    public URL getImage_path() {return image_path;}
    public int getAgilitat() {return agilitat;}
    public int getDefensa() {return defensa;}
    public int getForca() {return forca;}
    public int getVelocitat() {return velocitat;}
    public int getVida() {return vida;}
}