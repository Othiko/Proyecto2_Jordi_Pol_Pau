package InterfaceGrafica;

public class Warriors extends Race{
	private int id, race;
    private String name, image_path;
	
	public Warriors(int id, String name, int race, String image_path, int race_id, int race_points, int life, int strenght, int defense, int agility, int speed) {
		super(race_id, race_points, life, strenght, defense, agility, speed);
		this.id  = id;
		this.name = name;
		this.race = race;
		this.image_path = image_path;
	}   

    /* GETTERS */
    public int getId() {return id;}
    public String getName() {return name;}
    public String getImage_path() {return image_path;}
    public int getRace() {return race;}
    
}