package InterfaceGrafica;

import java.util.ArrayList;

public class WarriorContainer {
    private ArrayList<Warriors> warriors;
    public WarriorContainer() {
        this.warriors = new ArrayList<Warriors>();
    }

    public void addNew(Warriors p) {
        this.warriors.add(p);
    }
    
    /* GETTERS */
    public ArrayList<Warriors> getWarriors() {return warriors;}
    
}
