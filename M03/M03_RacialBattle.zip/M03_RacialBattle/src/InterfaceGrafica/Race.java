package InterfaceGrafica;

public abstract class Race {
	private int race_id, race_points, life, strenght, defense, agility, speed;
	
	public Race(int race_id, int race_points, int life, int strenght, int defense, int agility, int speed) {
		this.race_id = race_id;
		this.race_points = race_points;
		this.life = life;
		this.strenght = strenght;
        this.defense = defense;
        this.agility = agility;
        this.speed = speed;
	}
	
	/* SETTERS */
	public void setAgility(int agility) {this.agility = agility;}
    public void setDefense(int defense) {this.defense = defense;}
    public void setStrenght(int strenght) {this.strenght = strenght;}
    public void setSpeed(int speed) {this.speed = speed;}
    public void setLife(int life) {this.life = life;}
    
    
    /* GETTERS */
    public int getAgility() {return agility;}
    public int getDefense() {return defense;}
    public int getStrenght() {return strenght;}
    public int getSpeed() {return speed;}
    public int getLife() {return life;}
    public int getRacePoints() {return race_points;}

}

