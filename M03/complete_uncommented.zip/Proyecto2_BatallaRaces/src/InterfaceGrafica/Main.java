package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;


import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class Main extends JFrame {
	private JPanel[] mainpanels = new JPanel[5];
	private fightPanel fightpanel;
	private JButton choosecharacter, chooseweapon, ranking, fight, clear;
	private JTextArea console;
	private JScrollPane scrollconsole;
	
	private String urlDatos, usuario, pass, query, update;
	private Boolean charselected = false, weapselected = false, playerwon = false;
	private int charselectedid = 0, weapselectedid = 0;
	
	private WeaponContainer weapCont = new WeaponContainer();
	private WarriorContainer warrCont = new WarriorContainer();
	private ArrayList<Integer> elve_weapons = new ArrayList<Integer>(), dwarf_weapons = new ArrayList<Integer>(), human_weapons = new ArrayList<Integer>();
	private Main mainframe; 
	
	// Fight.
	private int enemychar, enemyweap, enemy_race_id, player_global_points, player_damage_done, player_damage_taken, player_enemies_defeated, battle_points;
	private ArrayList<Integer> fightList = new ArrayList<Integer>();
	private Random rand = new Random();
	private int damage_done = 0, damage_taken = 0;

		
	public Main() {
		urlDatos = "jdbc:mysql://localhost/batallaRaces?serverTimezone=UTC";
	    usuario = "root";
	    pass = "1234";
	    
	    try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement statement = conn.createStatement();
            ResultSet rs;
			
			query = "select * from weapons";
            rs = statement.executeQuery(query);

            while (rs.next()) {
                weapCont.addNew(new Weapons(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getInt(6)));
            }

            query = "select warrior_id, warrior_name, w.id_race, warrior_image_path, r.race_id, race_points, race_life, race_strenght, race_defense, race_agility, race_speed from warriors w inner join races r on w.id_race=r.race_id";
            rs = statement.executeQuery(query);
            
            while (rs.next()) {
                warrCont.addNew(new Warriors(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getInt(10), rs.getInt(11)));
            }
            
            query = "select * from weapons_available";
            rs = statement.executeQuery(query);
            
            while (rs.next()) {
            	if (rs.getInt(1) == 1) {
            		dwarf_weapons.add(rs.getInt(2));
            	} else if (rs.getInt(1) == 2) {
            		human_weapons.add(rs.getInt(2));
            	} else if (rs.getInt(1) == 3) {
            		elve_weapons.add(rs.getInt(2));
            	}
            }
            
            query = "select player_global_points, player_enemies_defeated, player_damage_done, player_damage_taken from players where player_id =" +loginRegister.getUser_id();
            rs = statement.executeQuery(query);
            
            while (rs.next()) {
            	player_global_points = rs.getInt(1);
            	player_enemies_defeated = rs.getInt(2);
            	player_damage_done = rs.getInt(3);
            	player_damage_taken = rs.getInt(4);
            }
            
		} catch (ClassNotFoundException e) {System.out.println("El driver no se ha cargado correctamente.");}
        catch (SQLException e) {System.out.println("Error de SQL."); e.printStackTrace();}

		mainpanels[0] = new JPanel();
		mainpanels[0].setLayout(new BoxLayout(mainpanels[0], BoxLayout.Y_AXIS));
		for (int i=1;i<mainpanels.length;i++) {
			mainpanels[i] = new JPanel();
			mainpanels[i].setLayout(new FlowLayout(FlowLayout.CENTER));
		}
		
		choosecharacter = new JButton("Choose character");
		chooseweapon = new JButton("Choose weapon");
		ranking = new JButton("Ranking");
		fight = new JButton("Fight");
		clear = new JButton("Clear console");
		
		fightpanel = new fightPanel();
		
		console = new JTextArea(7,95);
		console.setEditable(false);
		scrollconsole = new JScrollPane(console);
		scrollconsole.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
		scrollconsole.setHorizontalScrollBarPolicy ( ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS );
		
		choosecharacter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new ChooseCharacter();
				
			}
		});
		
		chooseweapon.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (charselected) {
					setVisible(false);
					new ChooseWeapon();
				} else {
					JOptionPane.showMessageDialog(mainpanels[0], "Before chosing a weapon, please select a character.", "Character required.", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});
		
		ranking.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new ranking();
            }
		});
		
		fight.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (charselected && weapselected) {
					chooseweapon.setEnabled(false);
					if (e.getActionCommand().equalsIgnoreCase("Next Turn")) {
						new Fight();
					} else if (e.getActionCommand().equalsIgnoreCase("Fight")) {
						damage_done = 0;
						damage_taken = 0;
						battle_points = 0;
						playerwon = false;
						do {
							enemychar = rand.nextInt(9);
						} while (enemychar == charselectedid-1);
						
						enemy_race_id = warrCont.getWarriors().get(enemychar).getRace();
						
						ArrayList<Integer> enemy_available_weapons = new ArrayList<Integer>();
						
						if (enemy_race_id == 1) {
							enemy_available_weapons = dwarf_weapons;
						} else if (enemy_race_id == 2) {
							enemy_available_weapons = human_weapons;
						} else if (enemy_race_id == 3) {
							enemy_available_weapons = elve_weapons;
						}
						
						enemyweap = rand.nextInt(enemy_available_weapons.size());
						enemyweap = enemy_available_weapons.get(enemyweap);
						
						fightpanel.setCharacterEnemy(warrCont.getWarriors().get(enemychar).getImage_path());
						fightpanel.setWeaponEnemy(weapCont.getWeapons().get(enemyweap-1).getImage_Path());
						fightpanel.setHealthEnemy(warrCont.getWarriors().get(enemychar).getLife());
						fightpanel.setPowerEnemy(warrCont.getWarriors().get(enemychar).getStrenght(), weapCont.getWeapons().get(enemyweap-1).getWeaponPower());
						fightpanel.setAgilityEnemy(warrCont.getWarriors().get(enemychar).getAgility());
						fightpanel.setSpeedEnemy(warrCont.getWarriors().get(enemychar).getSpeed(), weapCont.getWeapons().get(enemyweap-1).getWeaponSpeed());
						fightpanel.setDefenseEnemy(warrCont.getWarriors().get(enemychar).getDefense());
						
						console.setText(console.getText() + warrCont.getWarriors().get(enemychar).getName() + " has challenged you to a duel. \nFIGTH!\n");
						
						if (fightpanel.speedally.getValue() > fightpanel.speedenemy.getValue()) {
							fightList.add(charselectedid-1);
							fightList.add(enemychar);
						} else if (fightpanel.speedally.getValue() < fightpanel.speedenemy.getValue()) {
							fightList.add(enemychar);
							fightList.add(charselectedid-1);
						} else {
							if (fightpanel.agilityally.getValue() > fightpanel.agilityenemy.getValue()) {
								fightList.add(charselectedid-1);
								fightList.add(enemychar);
							} else if (fightpanel.agilityally.getValue() < fightpanel.agilityenemy.getValue()) {
								fightList.add(enemychar);
								fightList.add(charselectedid-1);
							} else {
								int startrng = rand.nextInt(2);
								if (startrng == 0) {
									fightList.add(charselectedid-1);
									fightList.add(enemychar);
								} else if (startrng == 1) {
									fightList.add(enemychar);
									fightList.add(charselectedid-1);
								}
							}
						}
						new Fight();
					} else if (e.getActionCommand().equalsIgnoreCase("Finish")) {
						dispose();
						int restart = JOptionPane.showConfirmDialog(null, "Would you like to restart the game?", "Restart Game", JOptionPane.YES_NO_OPTION);
						if (restart == 0) {
							new Main();
						}
					}
				} else {
					JOptionPane.showMessageDialog(mainpanels[0], "Before starting the fight, please select a character and a weapon.", "Character and weapon required.", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		clear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				console.setText("");
			}
		});
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
		            Statement statement = conn.createStatement();
		            update = "update players set player_global_points = ?, player_enemies_defeated = ?, player_damage_done = ?, player_damage_taken = ? where player_id =" +loginRegister.getUser_id();
		            PreparedStatement ps = conn.prepareStatement(update);
		            ps.setInt(1, player_global_points);
		            ps.setInt(2, player_enemies_defeated);
		            ps.setInt(3, player_damage_done);
		            ps.setInt(4, player_damage_taken);
		            ps.executeUpdate();
		            
		            try {
		            	if (playerwon) {
			            	String insert = "insert into battle (id_player,id_warrior,warrior_weapon_id,oponent_id,oponent_weapon_id,injuries_caused,injuries_suffered,battle_points)" + "values ("+ loginRegister.getUser_id()+ ", "+charselectedid+", "+weapselectedid+", "+(enemychar+1)+", "+enemyweap+", "+damage_done+", "+damage_taken+", "+battle_points+")";                                                
				            statement.executeUpdate(insert);
			            } else {
			            	String insert = "insert into battle (id_player,id_warrior,warrior_weapon_id,oponent_id,oponent_weapon_id,injuries_caused,injuries_suffered,battle_points)" + "values ("+ loginRegister.getUser_id()+ ", "+charselectedid+", "+weapselectedid+", "+(enemychar+1)+", "+enemyweap+", "+damage_done+", "+damage_taken+", 0)";                                                
				            statement.executeUpdate(insert);
			            }
		            } catch (SQLIntegrityConstraintViolationException h) {}
		            
		            
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
	            
			}
		});
		
		mainpanels[1].add(choosecharacter);
		mainpanels[1].add(chooseweapon);
		mainpanels[1].add(ranking);
		
		mainpanels[2].add(fightpanel);
		
		mainpanels[3].add(fight);
		mainpanels[3].add(clear);
		
		mainpanels[4].add(scrollconsole);
		
		for (int i=1;i<mainpanels.length;i++) {
			mainpanels[0].add(mainpanels[i]);
		}
		
		this.add(mainpanels[0]);
		this.setSize(1150,750);
		this.setResizable(false);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		
		mainframe = this;
		
		
		if (mainframe == this) {
			
			mainframe.addWindowListener(new WindowListener() {
				@Override
				public void windowActivated(WindowEvent e) {
					if (charselected) {
						try {
							fightpanel.setCharacterAlly(warrCont.getWarriors().get(charselectedid-1).getImage_path());
							fightpanel.setHealthAlly(warrCont.getWarriors().get(charselectedid-1).getLife());
							fightpanel.setPowerAlly(warrCont.getWarriors().get(charselectedid-1).getStrenght());
							fightpanel.setAgilityAlly(warrCont.getWarriors().get(charselectedid-1).getAgility());
							fightpanel.setSpeedAlly(warrCont.getWarriors().get(charselectedid-1).getSpeed());
							fightpanel.setDefenseAlly(warrCont.getWarriors().get(charselectedid-1).getDefense());
						} catch (IndexOutOfBoundsException z) {}
					}
					if (weapselected) {
						try {
							fightpanel.setWeaponAlly(weapCont.getWeapons().get(weapselectedid-1).getImage_Path());
							fightpanel.setWeaponPowerAlly(warrCont.getWarriors().get(charselectedid-1).getStrenght(), weapCont.getWeapons().get(weapselectedid-1).getWeaponPower());
							fightpanel.setWeaponSpeedAlly(warrCont.getWarriors().get(charselectedid-1).getSpeed(), weapCont.getWeapons().get(weapselectedid-1).getWeaponSpeed());
						} catch (IndexOutOfBoundsException z) {}
					}
				}
				
				@Override
				public void windowOpened(WindowEvent e) {}
				@Override
				public void windowClosing(WindowEvent e) {}
				@Override
				public void windowClosed(WindowEvent e) {}
				@Override
				public void windowIconified(WindowEvent e) {}
				@Override
				public void windowDeiconified(WindowEvent e) {}
				@Override
				public void windowDeactivated(WindowEvent e) {}
			});
		} 
		
	}
	
	class fightPanel extends JPanel {
		private JPanel ally, allyspecifics, allystats, enemy, enemyspecifics, enemystats, healthallypanel, healthenemypanel, characterallypanel, characterenemypanel, allyweaponpanel, enemyweaponpanel, allystatslabelpanel, enemystatslabelpanel;
		private JProgressBar healthally, powerally, agilityally, speedally, defenseally, healthenemy, powerenemy, agilityenemy, speedenemy, defenseenemy;
		private JLabel stat1ally, stat2ally, stat3ally, stat4ally, stat1enemy, stat2enemy, stat3enemy, stat4enemy, characterally, weaponally, characterenemy, weaponenemy;
		
		fightPanel() {
			ally = new JPanel();
			ally.setLayout(new BoxLayout(ally, BoxLayout.Y_AXIS));
			enemy = new JPanel();
			enemy.setLayout(new BoxLayout(enemy, BoxLayout.Y_AXIS));
			
			healthallypanel = new JPanel();
			healthenemypanel = new JPanel();
			characterallypanel = new JPanel();
			characterenemypanel = new JPanel();
			allyspecifics = new JPanel();
			allyspecifics.setLayout(new BorderLayout(5,5));
			enemyspecifics = new JPanel();
			enemyspecifics.setLayout(new BorderLayout(5,5));
			
			allyweaponpanel = new JPanel();
			enemyweaponpanel = new JPanel();
			allystatslabelpanel = new JPanel();
			allystatslabelpanel.setLayout(new BoxLayout(allystatslabelpanel, BoxLayout.Y_AXIS));
			enemystatslabelpanel = new JPanel();
			enemystatslabelpanel.setLayout(new BoxLayout(enemystatslabelpanel, BoxLayout.Y_AXIS));
			allystats = new JPanel();
			allystats.setLayout(new BoxLayout(allystats, BoxLayout.Y_AXIS));
			allystats.setBorder(new EmptyBorder(5,0,0,5));
			enemystats = new JPanel();
			enemystats.setLayout(new BoxLayout(enemystats, BoxLayout.Y_AXIS));
			enemystats.setBorder(new EmptyBorder(5,0,0,5));
			
			healthally = new JProgressBar(0,0); 
			healthally.setStringPainted(true);
			healthally.setPreferredSize(new Dimension(330,35));
			healthally.setValue(0);
			healthally.setForeground(Color.green);
			powerally = new JProgressBar(0,11);
			powerally.setPreferredSize(new Dimension(150,25));
			powerally.setValue(0);
			powerally.setForeground(Color.red);
			agilityally = new JProgressBar(0,7);
			agilityally.setPreferredSize(new Dimension(150,25));
			agilityally.setValue(0);
			agilityally.setForeground(Color.pink);
			speedally = new JProgressBar(0,12);
			speedally.setPreferredSize(new Dimension(150,25));
			speedally.setValue(0);
			speedally.setForeground(Color.yellow);
			defenseally = new JProgressBar(0,4);
			defenseally.setPreferredSize(new Dimension(150,25));
			defenseally.setValue(0);
			defenseally.setForeground(Color.blue);
			
			allystats.add(powerally);
			allystats.add(agilityally);
			allystats.add(speedally);
			allystats.add(defenseally);
			
			healthenemy = new JProgressBar(0,0); 
			healthenemy.setStringPainted(true);
			healthenemy.setPreferredSize(new Dimension(330,35));
			healthenemy.setValue(0);
			healthenemy.setForeground(Color.green);
			powerenemy = new JProgressBar(0,11);
			powerenemy.setPreferredSize(new Dimension(150,25));
			powerenemy.setValue(0);
			powerenemy.setForeground(Color.red);
			agilityenemy = new JProgressBar(0,7);
			agilityenemy.setPreferredSize(new Dimension(150,25));
			agilityenemy.setValue(0);
			agilityenemy.setForeground(Color.pink);
			speedenemy = new JProgressBar(0,12);
			speedenemy.setPreferredSize(new Dimension(150,25));
			speedenemy.setValue(0);
			speedenemy.setForeground(Color.yellow);
			defenseenemy = new JProgressBar(0,4);
			defenseenemy.setPreferredSize(new Dimension(150,25));
			defenseenemy.setValue(0);
			defenseenemy.setForeground(Color.blue);
			
			enemystats.add(powerenemy);
			enemystats.add(agilityenemy);
			enemystats.add(speedenemy);
			enemystats.add(defenseenemy);
			
			stat1ally = new JLabel("Power");
			stat2ally = new JLabel("Agility");
			stat3ally = new JLabel("Speed");
			stat4ally = new JLabel("Defense");
			allystatslabelpanel.add(stat1ally);
			allystatslabelpanel.add(stat2ally);
			allystatslabelpanel.add(stat3ally);
			allystatslabelpanel.add(stat4ally);
			
			stat1enemy = new JLabel("Power");
			stat2enemy = new JLabel("Agility");
			stat3enemy = new JLabel("Speed");
			stat4enemy = new JLabel("Defense");
			enemystatslabelpanel.add(stat1enemy);
			enemystatslabelpanel.add(stat2enemy);
			enemystatslabelpanel.add(stat3enemy);
			enemystatslabelpanel.add(stat4enemy);
			
			characterally = new JLabel(new ImageIcon("not_selected.png"));
			characterally.setPreferredSize(new Dimension(330,330));
			weaponally = new JLabel(new ImageIcon(new ImageIcon("not_selected.png").getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));
			weaponally.setPreferredSize(new Dimension(55,55));
			characterenemy = new JLabel(new ImageIcon("not_selected.png"));
			characterenemy.setPreferredSize(new Dimension(330,330));
			weaponenemy = new JLabel(new ImageIcon(new ImageIcon("not_selected.png").getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));
			weaponenemy.setPreferredSize(new Dimension(55,55));
			
			healthallypanel.add(healthally);
			healthenemypanel.add(healthenemy);
			characterallypanel.add(characterally);
			characterenemypanel.add(characterenemy);
			
			allyweaponpanel.add(weaponally);
			enemyweaponpanel.add(weaponenemy);
			
			allyspecifics.add(allyweaponpanel, BorderLayout.WEST);
			allyspecifics.add(allystatslabelpanel, BorderLayout.CENTER);
			allyspecifics.add(allystats, BorderLayout.EAST);
			
			enemyspecifics.add(enemyweaponpanel, BorderLayout.WEST);
			enemyspecifics.add(enemystatslabelpanel, BorderLayout.CENTER);
			enemyspecifics.add(enemystats, BorderLayout.EAST);
			
			ally.add(healthallypanel);
			ally.add(characterallypanel);
			ally.add(allyspecifics);
			
			enemy.add(healthenemypanel);
			enemy.add(characterenemypanel);
			enemy.add(enemyspecifics);
			
			this.setLayout(new BorderLayout(100,10));
			this.add(ally, BorderLayout.WEST);
			this.add(enemy, BorderLayout.EAST);
		}	
		
		public void setCharacterAlly(String character_img_path) {characterally.setIcon(new ImageIcon(character_img_path));}
		public void setWeaponAlly(String weapon_img_path) {weaponally.setIcon(new ImageIcon(new ImageIcon(weapon_img_path).getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));}
		public void setHealthAlly(int healthally) {this.healthally.setMaximum(healthally); this.healthally.setValue(healthally);}
		public void setPowerAlly(int powerally) {this.powerally.setValue(powerally);}
		public void setAgilityAlly(int agilityally) {this.agilityally.setValue(agilityally);}
		public void setSpeedAlly(int speedally) {this.speedally.setValue(speedally);}
		public void setDefenseAlly(int defenseally) {this.defenseally.setValue(defenseally);}
		public void setWeaponPowerAlly(int powerally, int powerweapon) {this.powerally.setValue(powerally + powerweapon);}
		public void setWeaponSpeedAlly(int speedally, int speedweapon) {this.speedally.setValue(speedally + speedweapon);}
		
		public void setCharacterEnemy(String character_img_path) {characterenemy.setIcon(new ImageIcon(character_img_path));}
		public void setWeaponEnemy(String weapon_img_path) {weaponenemy.setIcon(new ImageIcon(new ImageIcon(weapon_img_path).getImage().getScaledInstance(55, 55, Image.SCALE_SMOOTH)));}
		public void setHealthEnemy(int healthenemy) {this.healthenemy.setMaximum(healthenemy); this.healthenemy.setValue(healthenemy);}
		public void setPowerEnemy(int powerenemy, int powerweapon) {this.powerenemy.setValue(powerenemy + powerweapon);}
		public void setAgilityEnemy(int agilityenemy) {this.agilityenemy.setValue(agilityenemy);}
		public void setSpeedEnemy(int speedenemy, int speedweapon) {this.speedenemy.setValue(speedenemy + speedweapon);}
		public void setDefenseEnemy(int defenseenemy) {this.defenseenemy.setValue(defenseenemy);}
	}


	public static class loginRegister extends JFrame {
		private JPanel main,messages,userpassw,userrep,buttons,users,passwords;
		private JLabel message,userlabel,passwlabel,errorslab;
		private JTextField usertextfield;
		private JPasswordField passwordfield;
		private JButton login,register;
		private String urlDatos = "jdbc:mysql://localhost/batallaRaces?serverTimezone=UTC";
		private String usuario = "root";
		private String pass = "1234";
		private String sql, user, password;
		private static int user_id;

		/* loginRegister() may throw ClassNotFoundException or SQLException. */
		public loginRegister() throws ClassNotFoundException, SQLException {
			/* Stablish the connection with our database. */
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(urlDatos,usuario,pass);

			/* Instantiate all JPanels needed. */
			main=new JPanel();messages=new JPanel();
			userpassw=new JPanel();
			userrep=new JPanel();
			buttons=new JPanel();
			users=new JPanel();
			passwords=new JPanel();
			/* Instantiate all JLabels needed. */
			message=new JLabel("Login or Register a user");
			userlabel=new JLabel("User: ");
			passwlabel=new JLabel("Password: ");
			errorslab=new JLabel();
			usertextfield=new JTextField(10);		// Instantiate username JTextField.
			passwordfield=new JPasswordField(10);		// Instantiate user pass JPasswordField.
			login=new JButton("Login");
			register=new JButton("Register");	// Instantiate all JButtons needed.

			/* Set a layout for every JPanel in Login. */
			userpassw.setLayout(new GridLayout(2,1));
			main.setLayout(new GridLayout(1,1));
			message.setAlignmentX(CENTER_ALIGNMENT);
			userpassw.setAlignmentX(CENTER_ALIGNMENT);

			/* Add all objects to their respective JPanels. */
			users.add(userlabel);
			users.add(usertextfield);
			passwords.add(passwlabel);
			passwords.add(passwordfield);
			messages.add(message,BorderLayout.CENTER);
			userpassw.add(users);
			userpassw.add(passwords);
			userrep.add(errorslab);
			buttons.add(login);
			buttons.add(register);

			/* When login JButton clicked, check: */
			login.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					/* We create a variable which values are the user and the password */
					user = usertextfield.getText();
					password = String.valueOf(passwordfield.getPassword());
					/* With that query we check if the users already exists. */
					sql = "SELECT * FROM players WHERE player_name = '"+user+"' AND player_password = '"+password+"'";
					PreparedStatement statement = null;
					ResultSet result = null;
					try {
						statement = conn.prepareStatement(sql);
						result = statement.executeQuery();

						if (result.next()) {
						/* If there's a result it means that there's a username that uses the same password, so the user
						 can just login. */
							errorslab.setText("Login successful!");
							user_id = result.getInt(1);
							dispose();
							new Main();
						} else {
						/* If there are no results, it means there's no user with the password you've provided,
						then you should register a new account. */
							errorslab.setText("Invalid username or password!");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			});

			/* When register JButton clicked, check: */
			register.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					/* We obtain the username and password written and check if it's in our database. */
					user = usertextfield.getText();
					password = String.valueOf(passwordfield.getPassword());
					sql = "SELECT * FROM players WHERE player_name = '"+user+"'";

					PreparedStatement statement = null;
					ResultSet result = null;
					try {
						statement = conn.prepareStatement(sql);
						result = statement.executeQuery();
						if (result.next()) {
						/* If there's a result, user can't register because there's an account with
						the same username. */
							errorslab.setText("User already exists");
						} else {
							/* If there are no results, then we create the new account. */
							sql = "insert into players(player_name,player_password,player_global_points,player_enemies_defeated,player_damage_done,player_damage_taken) "
									+ "values ('"+user+"','"+password+"',0,0,0,0)";
							PreparedStatement statement1 = conn.prepareStatement(sql);
							statement1.executeUpdate();
							errorslab.setText("User created succesfully");
						}
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				}
			});
			
			/* We add the remaining objects to their JPanels. */
			main.add(message);main.add(userpassw);main.add(buttons);main.add(userrep);
			main.setLayout(new BoxLayout(main,BoxLayout.Y_AXIS));
			this.add(main);
			this.setSize(300,250);
			this.setVisible(true);
			this.setLocationRelativeTo(null);
			this.setResizable(false);
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		}

		public static int getUser_id() {return user_id;}
	}

	
	class ChooseCharacter extends JFrame {
		private JPanel panel;
		private JButton[] char_button = new JButton[9];
		
		public ChooseCharacter() {
			panel = new JPanel();
			panel.setLayout(new GridLayout(3,3,5,5));
			panel.setBorder(BorderFactory.createEmptyBorder(0,7,0,7));
			
			for (int i=0;i<warrCont.getWarriors().size();i++) {
				char_button[i] = new JButton(new ImageIcon(new ImageIcon(warrCont.getWarriors().get(i).getImage_path()).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH)));
				char_button[i].setBorderPainted(false);
				panel.add(char_button[i]);
			}
			
			this.addWindowListener(new WindowAdapter() {
				public void windowClosed(WindowEvent e) {
					mainframe.setVisible(true);
				}
			});
			
			char_button[0].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 1;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[1].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 2;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[2].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 3;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			});
			char_button[3].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 4;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[4].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 5;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[5].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 6;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[6].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 7;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[7].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 8;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			char_button[8].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent f) {
			    	charselectedid = 9;
				    charselected = true;
				    dispose();
				    mainframe.setVisible(true);
				}
			}); 
			
			this.toFront();
			this.requestFocus();
			this.add(panel);
			this.setSize(500,500);
			this.setResizable(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
		}
	}
	
	class ChooseWeapon extends JFrame {
		private JPanel panel;
		private JButton[] weap_button = new JButton[9];
		
		public ChooseWeapon() {
			panel = new JPanel();
			panel.setLayout(new GridLayout(3,3,5,5));
			panel.setBorder(BorderFactory.createEmptyBorder(0,7,0,7));
			
			int race_id = warrCont.getWarriors().get(charselectedid-1).getRace();
			ArrayList<Integer> available_weapons = new ArrayList<Integer>();
			if (race_id == 1) {
				available_weapons = dwarf_weapons;
				this.setSize(330,500);
			} else if (race_id == 2) {
				available_weapons = human_weapons;
				this.setSize(500,500);
			} else if (race_id == 3) {
				available_weapons = elve_weapons;
				this.setSize(330,500);
			}
			
			for (int i=0;i<available_weapons.size();i++) {
				weap_button[i] = new JButton(new ImageIcon(new ImageIcon(weapCont.getWeapons().get(available_weapons.get(i)-1).getImage_Path()).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH)));
				weap_button[i].setBorderPainted(false);
				weap_button[i].setSize(new Dimension(150,150));
				panel.add(weap_button[i]);
			}
			
			this.addWindowListener(new WindowAdapter() {
				public void windowClosed(WindowEvent e) {
					mainframe.setVisible(true);
				}
			});
			
			if (race_id == 1) {
				weap_button[0].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 2;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[1].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 3;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[2].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 8;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[3].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 9;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
			} else if (race_id == 2) {
				weap_button[0].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 1;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[1].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 2;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[2].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 3;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[3].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 4;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[4].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 5;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[5].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 7;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[6].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 8;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				
			} else if (race_id == 3) {
				weap_button[0].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 1;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[1].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 2;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[2].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 4;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[3].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 5;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[4].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 6;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
				weap_button[5].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						weapselectedid = 8;
						weapselected = true;
						dispose();
					    mainframe.setVisible(true);
					    choosecharacter.setEnabled(false);
					}
				});
			}
			
			this.toFront();
			this.requestFocus();
			this.add(panel);
			
			this.setResizable(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
		}
	}
	
	class Fight {
		
		Fight() {
				mainframe.console.setText(mainframe.console.getText() + "\n\nTurn of " + warrCont.getWarriors().get(fightList.get(0)).getName());
				int succesfulattack = rand.nextInt(100)+1;
				if (warrCont.getWarriors().get(fightList.get(0)).getAgility() * 10 > succesfulattack) {
					int dodgeattack = rand.nextInt(50)+1;
					if (warrCont.getWarriors().get(fightList.get(1)).getAgility() > dodgeattack) {
						mainframe.console.setText(mainframe.console.getText() + "\nThe defender has dodged the attack.");
					} else {
						mainframe.console.setText(mainframe.console.getText() + "\nThe attack has been succesful.");
						int dmgdealt;
						if (fightList.get(0) == charselectedid-1) {
							dmgdealt = fightpanel.powerally.getValue() - fightpanel.defenseenemy.getValue();
							mainframe.console.setText(mainframe.console.getText() + "\nThe attacker dealt " + dmgdealt + " damage to the defender.");
							fightpanel.healthenemy.setValue(fightpanel.healthenemy.getValue()-dmgdealt);
							mainframe.console.setText(mainframe.console.getText() + "\nAttacker's health = " + fightpanel.healthally.getValue());
							mainframe.console.setText(mainframe.console.getText() + "\nDefender's health = " + fightpanel.healthenemy.getValue());
							
							damage_done += dmgdealt;
							
						} else if (fightList.get(0) == enemychar) {
							dmgdealt = fightpanel.powerenemy.getValue() - fightpanel.defenseally.getValue();
							mainframe.console.setText(mainframe.console.getText() + "\nThe attacker dealt " + dmgdealt + " damage to the defender.");
							fightpanel.healthally.setValue(fightpanel.healthally.getValue()-dmgdealt);
							mainframe.console.setText(mainframe.console.getText() + "\nAttacker's health = " + fightpanel.healthally.getValue());
							mainframe.console.setText(mainframe.console.getText() + "\nDefender's health = " + fightpanel.healthenemy.getValue());
							
							damage_taken += dmgdealt;
						}
					}
				} else {
					mainframe.console.setText(mainframe.console.getText() + "\nThe attack has failed.");
				}
				
				mainframe.fight.setText("Next Turn");
				if (fightpanel.healthally.getValue() <= 0 || fightpanel.healthenemy.getValue() <= 0) {
					mainframe.fight.setText("Finish");
					mainframe.console.setText(mainframe.console.getText() + "\n\n" + warrCont.getWarriors().get(fightList.get(0)).getName() + " won!");
					if (fightList.get(0) == charselectedid-1) {
						player_enemies_defeated += 1;
						player_global_points += warrCont.getWarriors().get(enemychar).getRacePoints() + weapCont.getWeapons().get(enemyweap-1).getWeaponPoints();
						player_damage_done += damage_done;
						player_damage_taken += damage_taken;
						battle_points += warrCont.getWarriors().get(enemychar).getRacePoints() + weapCont.getWeapons().get(enemyweap-1).getWeaponPoints();
						playerwon = true;
					} else {
						player_damage_done += damage_done;
						player_damage_taken += damage_taken;
					}
				} else {
					if (fightList.get(0) == charselectedid-1) {
						if (fightpanel.speedally.getValue() <= fightpanel.speedenemy.getValue()) {
							Collections.swap(fightList, 0, 1);
							mainframe.console.setText(mainframe.console.getText() + "\nNow " + warrCont.getWarriors().get(fightList.get(0)).getName() + " is the attacker!");
						} else if (fightpanel.speedally.getValue() > fightpanel.speedenemy.getValue()) {
							int swapnum = rand.nextInt(100)+1;
							if ((fightpanel.speedally.getValue()-fightpanel.speedenemy.getValue())*10 > swapnum) {
								mainframe.console.setText(mainframe.console.getText() + "\n" + warrCont.getWarriors().get(fightList.get(0)).getName() + " is still the attacker.");
							} else {
								Collections.swap(fightList, 0, 1);
								mainframe.console.setText(mainframe.console.getText() + "\nNow " + warrCont.getWarriors().get(fightList.get(0)).getName() + " is the attacker!");
							}
						}
					} else if (fightList.get(0) == enemychar) {
						if (fightpanel.speedenemy.getValue() <= fightpanel.speedally.getValue()) {
							Collections.swap(fightList, 0, 1);
							mainframe.console.setText(mainframe.console.getText() + "\nNow " + warrCont.getWarriors().get(fightList.get(0)).getName() + " is the attacker!");
						} else if (fightpanel.speedenemy.getValue() > fightpanel.speedally.getValue()) {
							int swapnum = rand.nextInt(100)+1;
							if ((fightpanel.speedally.getValue()-fightpanel.speedenemy.getValue())*10 > swapnum) {
								mainframe.console.setText(mainframe.console.getText() + "\n" + warrCont.getWarriors().get(fightList.get(0)).getName() + " is still the attacker.");
							} else {
								Collections.swap(fightList, 0, 1);
								mainframe.console.setText(mainframe.console.getText() + "\nNow " + warrCont.getWarriors().get(fightList.get(0)).getName() + " is the attacker!");
							}
						}
					}
				}
		}	
	}
	
	public class ranking extends JFrame {
		private String urlDatos = "jdbc:mysql://localhost/batallaraces?serverTimezone=UTC";
		private String usuario = "root";
		private String pass = "1234";
		
		private JPanel mainpanel, buttons;
		private JScrollPane rankings;
		private JButton globalpoints,enemiesdefeated,damagedone,damagetaken;
		private JTable globalpointsrank, enemiesdefeatedrank, damagedonerank, damagetakenrank;

		
		public ranking() {
			mainpanel = new JPanel();
			mainpanel.setLayout(new BoxLayout(mainpanel, BoxLayout.Y_AXIS));
			mainpanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			rankings = new JScrollPane();
			buttons= new JPanel();
			buttons.setLayout(new GridBagLayout());
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
				Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
				
				String consultaEmp = "select player_name,player_global_points from players order by player_global_points desc limit 10;";
				ResultSet rs = stmnt.executeQuery(consultaEmp);
				ResultSetMetaData rsmd = rs.getMetaData();
				int i = 0;
				while (rs.next()) {
					i++;
				}
				String[][] pointsdata = new String[i][3];
				rs = stmnt.executeQuery(consultaEmp);
				i = 0;
				while (rs.next()) {
					pointsdata[i][0] = Integer.toString(i+1);
					pointsdata[i][1] = rs.getString(1);
					pointsdata[i][2] = Integer.toString(rs.getInt(2));
					i++;
				}
				String[] pointscolumns = {"Position", "Player", "Total Points"};
				
				consultaEmp = "select player_name,player_enemies_defeated from players order by player_enemies_defeated desc limit 10;";
				rs = stmnt.executeQuery(consultaEmp);
				rsmd = rs.getMetaData();
				i = 0;
				while (rs.next()) {
					i++;
				}
				String[][] defeateddata = new String[i][3];
				rs = stmnt.executeQuery(consultaEmp);
				i = 0;
				while (rs.next()) {
					defeateddata[i][0] = Integer.toString(i+1);
					defeateddata[i][1] = rs.getString(1);
					defeateddata[i][2] = Integer.toString(rs.getInt(2));
					i++;
				}
				String[] defeatedcolumns = {"Position", "Player", "Enemies Defeated"};
				
				consultaEmp = "select player_name,player_damage_done from players order by player_damage_done desc limit 10;";
				rs = stmnt.executeQuery(consultaEmp);
				rsmd = rs.getMetaData();
				i = 0;
				while (rs.next()) {
					i++;
				}
				String[][] dmgdealtdata = new String[i][3];
				rs = stmnt.executeQuery(consultaEmp);
				i = 0;
				while (rs.next()) {
					dmgdealtdata[i][0] = Integer.toString(i+1);
					dmgdealtdata[i][1] = rs.getString(1);
					dmgdealtdata[i][2] = Integer.toString(rs.getInt(2));
					i++;
				}
				String[] dmgdealtcolumns = {"Position", "Player", "Damage Dealt"};
				
				consultaEmp = "select player_name,player_damage_taken from players order by player_damage_taken desc limit 10;";
				rs = stmnt.executeQuery(consultaEmp);
				rsmd = rs.getMetaData();
				i = 0;
				while (rs.next()) {
					i++;
				}
				String[][] dmgreceiveddata = new String[i][3];
				rs = stmnt.executeQuery(consultaEmp);
				i = 0;
				while (rs.next()) {
					dmgreceiveddata[i][0] = Integer.toString(i+1);
					dmgreceiveddata[i][1] = rs.getString(1);
					dmgreceiveddata[i][2] = Integer.toString(rs.getInt(2));
					i++;
				}
				String[] dmgreceivedcolumns = {"Position", "Player", "Damage Received"};
				
				globalpointsrank = new JTable(pointsdata, pointscolumns);
				globalpointsrank.getColumnModel().getColumn(0).setPreferredWidth(30);
				enemiesdefeatedrank = new JTable(defeateddata, defeatedcolumns);
				enemiesdefeatedrank.getColumnModel().getColumn(0).setPreferredWidth(30);
				damagedonerank = new JTable(dmgdealtdata, dmgdealtcolumns);
				damagedonerank.getColumnModel().getColumn(0).setPreferredWidth(30);
				damagetakenrank = new JTable(dmgreceiveddata, dmgreceivedcolumns);
				damagetakenrank.getColumnModel().getColumn(0).setPreferredWidth(30);
				
			} catch (ClassNotFoundException e) {e.printStackTrace();} catch (SQLException e) {e.printStackTrace();}
			
			globalpoints=new JButton("Global Points");
			enemiesdefeated=new JButton("Enemies Defeated");
			damagedone=new JButton("Damage done");
			damagetaken=new JButton("Damage Recived");
			rankings.getViewport().add(globalpointsrank);
			
			globalpoints.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					rankings.getViewport().removeAll();
					rankings.getViewport().add(globalpointsrank);
				}	
			});
			enemiesdefeated.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					rankings.getViewport().removeAll();
					rankings.getViewport().add(enemiesdefeatedrank);
				}	
			});
			damagedone.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					rankings.getViewport().removeAll();
					rankings.getViewport().add(damagedonerank);
				}	
			});
			damagetaken.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					rankings.getViewport().removeAll();
					rankings.getViewport().add(damagetakenrank);
				}	
			});
			
			this.addWindowListener(new WindowAdapter() {
				public void windowClosed(WindowEvent e) {
					mainframe.setVisible(true);
				}
			});
			
			buttons.add(globalpoints);
			buttons.add(enemiesdefeated);
			buttons.add(damagedone);
			buttons.add(damagetaken);
			
			mainpanel.add(rankings);
			mainpanel.add(buttons);
			
			this.add(mainpanel);
			this.setSize(600,300);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			
			
			
		}
	}
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		new loginRegister();
	}

}