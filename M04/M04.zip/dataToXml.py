import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="1234",
  database="batallaraces"
)

mycursor = mydb.cursor()

mycursor.execute("select * from battle")

myresult = mycursor.fetchall()

with open("xml/battle.xml", "w") as f:
    f.write('' +
            '<?xml version="1.0"?>\n' +
            '<table name=\"battle\">\n')
    for dupla in myresult:
        f.write('     <row>\n')
        cont=0
        for dada in dupla:
            cont+=1
            f.write('' +
                '         <field name="'+ str(cont) +'">'+ str(dada) +'</field>\n')
        f.write(''+
            '     </row>\n')
    f.write('</table>')