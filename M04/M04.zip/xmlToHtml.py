import lxml.html
from lxml import etree

xslt_doc = etree.parse("xml/template.xsl")
xslt_transformer = etree.XSLT(xslt_doc)
source_doc = etree.parse("xml/battle.xml")
output_doc = xslt_transformer(source_doc)

output_doc.write("html/battle.html", pretty_print=True)
print(str(output_doc))